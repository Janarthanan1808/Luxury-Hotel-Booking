from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from datetime import datetime, timedelta
import json

app = Flask(__name__)
CORS(app)

# Google Sheets setup
scope = ['https://spreadsheets.google.com/feeds', 'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name(r'C:\Users\janar\Desktop\HotelBookingProject\src\linen-cubist-470308-m7-b76d822add44.json', scope)
client = gspread.authorize(creds)

# Replace with your Google Sheets ID
SPREADSHEET_ID = '1_Ik_4LfPFLbjD_wuef4GEhdl73KVAmxPjIN2jVj0ccE'
sheet = client.open_by_key(SPREADSHEET_ID)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/rooms')
def get_rooms():
    try:
        rooms_sheet = sheet.worksheet('Rooms')
        rooms_data = rooms_sheet.get_all_records()
        return jsonify(rooms_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/pricing', methods=['POST'])
def get_pricing():
    try:
        data = request.json
        check_in = data.get('check_in')
        check_out = data.get('check_out')
        
        pricing_sheet = sheet.worksheet('Pricing')
        pricing_data = pricing_sheet.get_all_records()
        
        # Filter pricing data by date range
        filtered_pricing = []
        check_in_date = datetime.strptime(check_in, '%Y-%m-%d')
        check_out_date = datetime.strptime(check_out, '%Y-%m-%d')
        
        for row in pricing_data:
            row_date = datetime.strptime(row['Date'], '%Y-%m-%d')
            if check_in_date <= row_date < check_out_date:
                filtered_pricing.append(row)
        
        return jsonify(filtered_pricing)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/availability', methods=['POST'])
def check_availability():
    try:
        data = request.json
        check_in = data.get('check_in')
        check_out = data.get('check_out')
        
        pricing_sheet = sheet.worksheet('Pricing')
        pricing_data = pricing_sheet.get_all_records()
        
        # Check availability for the date range
        availability = {}
        check_in_date = datetime.strptime(check_in, '%Y-%m-%d')
        check_out_date = datetime.strptime(check_out, '%Y-%m-%d')
        
        for row in pricing_data:
            row_date = datetime.strptime(row['Date'], '%Y-%m-%d')
            if check_in_date <= row_date < check_out_date:
                room_type = row['Room_Type']
                available_rooms = row['Available_Rooms']
                
                if room_type not in availability:
                    availability[room_type] = available_rooms
                else:
                    availability[room_type] = min(availability[room_type], available_rooms)
        
        return jsonify(availability)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/calculate-price', methods=['POST'])
def calculate_price():
    try:
        data = request.json
        check_in = data.get('check_in')
        check_out = data.get('check_out')
        room_type = data.get('room_type')
        adults = int(data.get('adults', 1))
        children = int(data.get('children', 0))
        breakfast = data.get('breakfast', False)
        
        pricing_sheet = sheet.worksheet('Pricing')
        pricing_data = pricing_sheet.get_all_records()
        
        total_price = 0
        check_in_date = datetime.strptime(check_in, '%Y-%m-%d')
        check_out_date = datetime.strptime(check_out, '%Y-%m-%d')
        nights = (check_out_date - check_in_date).days
        
        for row in pricing_data:
            row_date = datetime.strptime(row['Date'], '%Y-%m-%d')
            if (check_in_date <= row_date < check_out_date and 
                row['Room_Type'] == room_type):
                
                # Base price calculation
                if adults == 1:
                    night_price = row['Single_Rate']
                else:
                    night_price = row['Double_Rate']
                    if adults > 2:
                        night_price += (adults - 2) * row['Extra_Person']
                
                # Add children cost
                night_price += children * row['Extra_Child']
                
                # Add breakfast cost
                if breakfast:
                    night_price += row['With_Breakfast']
                
                total_price += night_price
        
        return jsonify({
            'total_price': total_price,
            'nights': nights,
            'price_per_night': total_price / nights if nights > 0 else 0
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/book', methods=['POST'])
def make_booking():
    try:
        data = request.json
        bookings_sheet = sheet.worksheet('Bookings')
        
        # Generate booking ID
        existing_bookings = bookings_sheet.get_all_records()
        booking_id = len(existing_bookings) + 1
        
        # Add booking to sheet
        booking_data = [
            booking_id,
            data.get('guest_name'),
            data.get('email'),
            data.get('phone'),
            data.get('check_in'),
            data.get('check_out'),
            data.get('room_type'),
            data.get('adults'),
            data.get('children'),
            data.get('breakfast'),
            data.get('total_amount'),
            'Confirmed'
        ]
        
        bookings_sheet.append_row(booking_data)
        
        return jsonify({
            'success': True,
            'booking_id': booking_id,
            'message': 'Booking confirmed successfully!'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)