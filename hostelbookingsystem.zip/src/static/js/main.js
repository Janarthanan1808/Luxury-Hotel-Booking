// Global variables
let currentBookingData = {};
let roomsData = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    setMinDates();
    loadRooms();
    setupEventListeners();
});

// Set minimum dates for check-in and check-out
function setMinDates() {
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    
    document.getElementById('checkIn').min = today;
    document.getElementById('checkIn').value = today;
    document.getElementById('checkOut').min = tomorrow;
    document.getElementById('checkOut').value = tomorrow;
}

// Setup event listeners
function setupEventListeners() {
    // Search form submission
    document.getElementById('searchForm').addEventListener('submit', handleSearch);
    
    // Date change listeners
    document.getElementById('checkIn').addEventListener('change', function() {
        const checkInDate = new Date(this.value);
        const nextDay = new Date(checkInDate.getTime() + 86400000);
        document.getElementById('checkOut').min = nextDay.toISOString().split('T')[0];
        
        if (document.getElementById('checkOut').value <= this.value) {
            document.getElementById('checkOut').value = nextDay.toISOString().split('T')[0];
        }
    });
    
    // Booking form submission
    document.getElementById('bookingForm').addEventListener('submit', handleBooking);
    
    // Breakfast checkbox change
    document.getElementById('breakfast').addEventListener('change', updatePriceSummary);
}

// Load rooms data
async function loadRooms() {
    try {
        showLoading(true);
        const response = await fetch('/api/rooms');
        roomsData = await response.json();
        displayRooms(roomsData);
    } catch (error) {
        console.error('Error loading rooms:', error);
        showNotification('Error loading rooms data', 'error');
    } finally {
        showLoading(false);
    }
}

// Display rooms in the grid
function displayRooms(rooms, pricing = null, availability = null) {
    const roomsGrid = document.getElementById('roomsGrid');
    roomsGrid.innerHTML = '';
    
    rooms.forEach((room, index) => {
        const roomCard = createRoomCard(room, pricing, availability, index);
        roomsGrid.appendChild(roomCard);
    });
}

// Create individual room card
function createRoomCard(room, pricing = null, availability = null, index = 0) {
    const roomCard = document.createElement('div');
    roomCard.className = 'room-card';
    roomCard.style.animationDelay = `${index * 0.1}s`;
    
    const isAvailable = availability ? availability[room.Room_Type] > 0 : true;
    const currentPrice = pricing ? calculateRoomPrice(room.Room_Type, pricing) : room.Base_Price;
    
    roomCard.innerHTML = `
        <div class="room-image" style="background-image: url('/static/images/${room.Image_URL}')">
            <div class="room-badge">${room.Room_Type}</div>
        </div>
        <div class="room-content">
            <h3 class="room-title">${room.Room_Type} Room</h3>
            <div class="room-features">
                <span><i class="fas fa-users"></i> ${room.Max_Occupancy} Guests</span>
                <span><i class="fas fa-wifi"></i> Free WiFi</span>
                <span><i class="fas fa-tv"></i> Smart TV</span>
            </div>
            <p class="room-description">${room.Description}</p>
            <div class="room-price">
                ${currentPrice}<span>/night</span>
            </div>
            <button class="book-now-btn" 
                    ${!isAvailable ? 'disabled' : ''} 
                    onclick="openBookingModal('${room.Room_Type}', ${currentPrice})">
                <i class="fas fa-calendar-check"></i>
                ${isAvailable ? 'Book Now' : 'Not Available'}
            </button>
            ${availability && availability[room.Room_Type] <= 3 && availability[room.Room_Type] > 0 ? 
                `<p class="availability-warning">Only ${availability[room.Room_Type]} rooms left!</p>` : ''}
        </div>
    `;
    
    return roomCard;
}

// Handle search form submission
async function handleSearch(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const searchData = {
        check_in: formData.get('checkIn'),
        check_out: formData.get('checkOut'),
        adults: formData.get('adults'),
        children: formData.get('children')
    };
    
    // Validate dates
    if (new Date(searchData.check_in) >= new Date(searchData.check_out)) {
        showNotification('Check-out date must be after check-in date', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        // Get pricing and availability
        const [pricingResponse, availabilityResponse] = await Promise.all([
            fetch('/api/pricing', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(searchData)
            }),
            fetch('/api/availability', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(searchData)
            })
        ]);
        
        const pricing = await pricingResponse.json();
        const availability = await availabilityResponse.json();
        
        // Update global search data
        currentBookingData = { ...searchData, pricing, availability };
        
        // Display updated rooms
        displayRooms(roomsData, pricing, availability);
        
        // Scroll to rooms section
        document.getElementById('rooms').scrollIntoView({ behavior: 'smooth' });
        
        showNotification('Search completed successfully!', 'success');
        
    } catch (error) {
        console.error('Search error:', error);
        showNotification('Error searching for rooms', 'error');
    } finally {
        showLoading(false);
    }
}

// Calculate room price based on search criteria
function calculateRoomPrice(roomType, pricing) {
    if (!pricing || pricing.length === 0) return 0;
    
    const roomPricing = pricing.filter(p => p.Room_Type === roomType);
    if (roomPricing.length === 0) return 0;
    
    // Calculate average price for the stay period
    const totalPrice = roomPricing.reduce((sum, day) => {
        const adults = parseInt(currentBookingData.adults) || 1;
        let dayPrice = adults === 1 ? day.Single_Rate : day.Double_Rate;
        
        if (adults > 2) {
            dayPrice += (adults - 2) * day.Extra_Person;
        }
        
        const children = parseInt(currentBookingData.children) || 0;
        dayPrice += children * day.Extra_Child;
        
        return sum + dayPrice;
    }, 0);
    
    return Math.round(totalPrice / roomPricing.length);
}

// Open booking modal
async function openBookingModal(roomType, basePrice) {
    const modal = document.getElementById('bookingModal');
    
    // Populate booking details
    const checkIn = document.getElementById('checkIn').value;
    const checkOut = document.getElementById('checkOut').value;
    const adults = document.getElementById('adults').value;
    const children = document.getElementById('children').value;
    
    if (!checkIn || !checkOut) {
        showNotification('Please select check-in and check-out dates first', 'error');
        return;
    }
    
    // Calculate nights
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
    
    // Update global booking data
    currentBookingData = {
        ...currentBookingData,
        room_type: roomType,
        base_price: basePrice,
        nights: nights
    };
    
    // Populate booking details section
    const bookingDetails = document.getElementById('bookingDetails');
    bookingDetails.innerHTML = `
        <h3>Booking Summary</h3>
        <div class="booking-info">
            <p><strong>Room Type:</strong> ${roomType}</p>
            <p><strong>Check-in:</strong> ${formatDate(checkIn)}</p>
            <p><strong>Check-out:</strong> ${formatDate(checkOut)}</p>
            <p><strong>Duration:</strong> ${nights} night${nights > 1 ? 's' : ''}</p>
            <p><strong>Guests:</strong> ${adults} adult${adults > 1 ? 's' : ''}${children > 0 ? `, ${children} child${children > 1 ? 'ren' : ''}` : ''}</p>
        </div>
    `;
    
    // Calculate and display initial price
    await updatePriceSummary();
    
    // Show modal with animation
    modal.style.display = 'block';
    setTimeout(() => modal.classList.add('show'), 10);
}

// Update price summary
async function updatePriceSummary() {
    try {
        const breakfast = document.getElementById('breakfast').checked;
        
        const response = await fetch('/api/calculate-price', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                check_in: currentBookingData.check_in || document.getElementById('checkIn').value,
                check_out: currentBookingData.check_out || document.getElementById('checkOut').value,
                room_type: currentBookingData.room_type,
                adults: currentBookingData.adults || document.getElementById('adults').value,
                children: currentBookingData.children || document.getElementById('children').value,
                breakfast: breakfast
            })
        });
        
        const priceData = await response.json();
        
        const priceSummary = document.getElementById('priceSummary');
        priceSummary.innerHTML = `
            <h3>Price Breakdown</h3>
            <div class="price-item">
                <span>Room Rate (${priceData.nights} nights)</span>
                <span>${(priceData.total_price - (breakfast ? priceData.nights * 25 : 0)).toFixed(2)}</span>
            </div>
            ${breakfast ? `
                <div class="price-item">
                    <span>Breakfast (${priceData.nights} nights)</span>
                    <span>${(priceData.nights * 25).toFixed(2)}</span>
                </div>
            ` : ''}
            <div class="price-item total">
                <span><strong>Total Amount</strong></span>
                <span><strong>${priceData.total_price.toFixed(2)}</strong></span>
            </div>
        `;
        
        currentBookingData.total_amount = priceData.total_price;
        
    } catch (error) {
        console.error('Error updating price:', error);
        showNotification('Error calculating price', 'error');
    }
}

// Handle booking form submission
async function handleBooking(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const bookingData = {
        ...currentBookingData,
        guest_name: formData.get('guestName') || document.getElementById('guestName').value,
        email: formData.get('guestEmail') || document.getElementById('guestEmail').value,
        phone: formData.get('guestPhone') || document.getElementById('guestPhone').value,
        breakfast: document.getElementById('breakfast').checked
    };
    
    // Validate required fields
    if (!bookingData.guest_name || !bookingData.email || !bookingData.phone) {
        showNotification('Please fill in all required fields', 'error');
        return;
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(bookingData.email)) {
        showNotification('Please enter a valid email address', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('/api/book', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(bookingData)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showNotification(`Booking confirmed! Your booking ID is: ${result.booking_id}`, 'success');
            closeModal();
            
            // Reset form
            document.getElementById('searchForm').reset();
            setMinDates();
            
            // Refresh rooms display
            displayRooms(roomsData);
            
            // Show confirmation details
            showBookingConfirmation(result.booking_id, bookingData);
        } else {
            throw new Error(result.message || 'Booking failed');
        }
        
    } catch (error) {
        console.error('Booking error:', error);
        showNotification('Error processing booking. Please try again.', 'error');
    } finally {
        showLoading(false);
    }
}

// Show booking confirmation
function showBookingConfirmation(bookingId, bookingData) {
    const confirmationHTML = `
        <div class="confirmation-modal">
            <div class="confirmation-content">
                <div class="success-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h2>Booking Confirmed!</h2>
                <p><strong>Booking ID:</strong> ${bookingId}</p>
                <p><strong>Guest:</strong> ${bookingData.guest_name}</p>
                <p><strong>Room:</strong> ${bookingData.room_type}</p>
                <p><strong>Dates:</strong> ${formatDate(bookingData.check_in)} - ${formatDate(bookingData.check_out)}</p>
                <p><strong>Total:</strong> ${bookingData.total_amount.toFixed(2)}</p>
                <button onclick="closeConfirmation()" class="confirmation-btn">Close</button>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', confirmationHTML);
    
    setTimeout(() => {
        document.querySelector('.confirmation-modal').classList.add('show');
    }, 10);
}

// Close booking confirmation
function closeConfirmation() {
    const confirmation = document.querySelector('.confirmation-modal');
    if (confirmation) {
        confirmation.remove();
    }
}

// Close booking modal
function closeModal() {
    const modal = document.getElementById('bookingModal');
    modal.style.display = 'none';
    modal.classList.remove('show');
    
    // Reset form
    document.getElementById('bookingForm').reset();
}

// Utility functions
function formatDate(dateString) {
    const options = { 
        weekday: 'short', 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
    };
    return new Date(dateString).toLocaleDateString('en-US', options);
}

function showLoading(show) {
    const spinner = document.getElementById('loadingSpinner');
    spinner.style.display = show ? 'flex' : 'none';
}

function showNotification(message, type = 'info') {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(n => n.remove());
    
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
            <button onclick="this.parentElement.parentElement.remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;
    
    document.body.appendChild(notification);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function scrollToBooking() {
    document.getElementById('booking').scrollIntoView({ 
        behavior: 'smooth' 
    });
}

// Smooth scrolling for navigation links
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-menu a[href^="#"]');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href').substring(1);
            const targetElement = document.getElementById(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });
});

// Handle window resize
window.addEventListener('resize', function() {
    // Adjust modal position if open
    const modal = document.getElementById('bookingModal');
    if (modal.style.display === 'block') {
        // Recalculate modal position
        const modalContent = modal.querySelector('.modal-content');
        modalContent.style.marginTop = Math.max(window.innerHeight * 0.05, 20) + 'px';
    }
});

// Add CSS for notifications and confirmations
const additionalCSS = `
.notification {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 4000;
    background: white;
    border-radius: 10px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    animation: slideInRight 0.3s ease;
    max-width: 400px;
}

.notification-content {
    padding: 1rem 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
}

.notification-success { border-left: 4px solid #28a745; }
.notification-error { border-left: 4px solid #dc3545; }
.notification-info { border-left: 4px solid #17a2b8; }

.notification-success i { color: #28a745; }
.notification-error i { color: #dc3545; }
.notification-info i { color: #17a2b8; }

.notification button {
    background: none;
    border: none;
    color: #999;
    cursor: pointer;
    margin-left: auto;
}

.confirmation-modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 5000;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.confirmation-modal.show {
    opacity: 1;
}

.confirmation-content {
    background: white;
    padding: 3rem;
    border-radius: 20px;
    text-align: center;
    max-width: 500px;
    width: 90%;
    transform: translateY(-20px);
    transition: transform 0.3s ease;
}

.confirmation-modal.show .confirmation-content {
    transform: translateY(0);
}

.success-icon {
    font-size: 4rem;
    color: #28a745;
    margin-bottom: 1rem;
}

.confirmation-btn {
    background: linear-gradient(45deg, #28a745, #20c997);
    color: white;
    border: none;
    padding: 1rem 2rem;
    border-radius: 10px;
    font-size: 1rem;
    cursor: pointer;
    margin-top: 2rem;
}

.availability-warning {
    color: #dc3545;
    font-size: 0.9rem;
    margin-top: 0.5rem;
    font-weight: bold;
}

.price-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
    padding: 0.5rem 0;
}

.price-item.total {
    border-top: 2px solid #e9ecef;
    margin-top: 1rem;
    padding-top: 1rem;
    font-size: 1.2rem;
}

.booking-info p {
    margin-bottom: 0.5rem;
    padding: 0.25rem 0;
}

@keyframes slideInRight {
    from {
        transform: translateX(100%);
        opacity: 0;
    }
    to {
        transform: translateX(0);
        opacity: 1;
    }
}

/* Mobile responsiveness for notifications */
@media (max-width: 768px) {
    .notification {
        top: 10px;
        right: 10px;
        left: 10px;
        max-width: none;
    }
    
    .confirmation-content {
        margin: 1rem;
        padding: 2rem;
    }
}
`;